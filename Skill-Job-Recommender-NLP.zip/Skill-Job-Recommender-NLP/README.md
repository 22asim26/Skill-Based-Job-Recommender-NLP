# Skill-Based Job Recommender using NLP

This project recommends jobs based on the user's input skills using TF-IDF and cosine similarity.

## Files
- Skill_Job_Recommender_NLP.ipynb
- resume_jobs_large.csv
- requirements.txt

## How to Run
1. Install dependencies:

pip install -r requirements.txt
2. Open the notebook and run all cells.

## Sample Input
```python
user_input = "Python, SQL, Power BI"
